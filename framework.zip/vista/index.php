<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="UTF-8" />
		<title><?=$this->meta_titulo?></title>
		<meta name="description" content="<?=$this->meta_descripcion?>" />
		<link rel="icon" type="image/vnd.microsoft.icon" href="<?=DIR_IMG?>/favicon.ico" />
		<link rel="SHORTCUT ICON" href="<?=DIR_IMG?>/favicon.ico" />
		<link rel="alternate" type="application/rss+xml" href="" title="" />
		<style type="text/css">@import "<?=DIR_CSS?>/comun.css";</style>
		<? $this->masEstilos(); ?>
		<!--[if lt IE 9]>
		<style type="text/css">@import "<?=DIR_CSS?>/ie.css";</style>
		<script type="text/javascript">
		   document.createElement("nav"); 
		   document.createElement("header"); 
		   document.createElement("footer"); 
		   document.createElement("section"); 
		   document.createElement("article"); 
		   document.createElement("aside"); 
		   document.createElement("hgroup"); 
		</script>
		<![endif]-->
		<script type="text/javascript" src="<?=DIR_JS?>/jquery.js"></script>
		<script type="text/javascript" src="<?=DIR_JS?>/plugins.js"></script>
		<script type="text/javascript" src="<?=DIR_JS?>/global.js"></script>
		<? $this->masScripts(); ?>
	</head>

	<body>
		<div id="envoltura">
			<header id="cabecera">
				<h1>Hola Mundo!</h1>
			</header>
			<div class="cuerpo">
				<?
					
				?>
			</div>
			<footer id="pie"></footer>
		</div>
	</body>
</html>